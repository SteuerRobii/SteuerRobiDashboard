import React from 'react'

export default function DashboardErweitert() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Willkommen bei SteuerRobi</h1>
      <p>Das beste Steuer-Dashboard Deutschlands. 🚀</p>
    </div>
  )
}