import React from 'react'
import ReactDOM from 'react-dom/client'
import DashboardErweitert from './DashboardErweitert'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DashboardErweitert />
  </React.StrictMode>
)